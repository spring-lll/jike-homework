-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 12 月 07 日 05:54
-- 服务器版本: 5.5.20
-- PHP 版本: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `phplesson`
--

-- --------------------------------------------------------

--
-- 表的结构 `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsid` int(11) NOT NULL AUTO_INCREMENT COMMENT '自动增长',
  `newstitle` varchar(100) NOT NULL,
  `newsimg` varchar(200) NOT NULL,
  `newscontent` text NOT NULL,
  `adddate` date NOT NULL,
  `source` varchar(64) NOT NULL,
  PRIMARY KEY (`newsid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=96 ;

--
-- 转存表中的数据 `news`
--

INSERT INTO `news` (`newsid`, `newstitle`, `newsimg`, `newscontent`, `adddate`, `source`) VALUES
(1, '北京市委副书记吕锡文接受调查 涉嫌严重违纪(图)', 'http://t10.baidu.com/it/u=http://e.hiphotos.baidu.com/news/w%3D638/sign=55cb1ec7b51bb0518f24b02b0e78da77/f3d3572c11dfa9ec76af44f264d0f703908fc156.jpg&fm=36', '搜狐科技从内部人士了解到，目前小米和高通的专利谈判，没有取得实质性进展，而即将发布的小米5可能...', '2015-11-12', '李白'),
(2, '北京市交通委:长安街公交专用道延伸至交叉路口', 'http://t12.baidu.com/it/u=http://d.hiphotos.baidu.com/news/crop%3D42%2C1%2C554%2C332%3Bw%3D638/sign=402e4a3aad64034f1b82984692f74b1d/71cf3bc79f3df8dcdad50b76cb11728b46102868.jpg&fm=36', '今后将在本市更多的公交专用车道上延伸至交叉路口和增设“借道区”交通标线，同时，还将视情况增设“...', '2015-11-04', ''),
(3, '通州8月限购以来部分环北京地区房价飙升', 'http://t11.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C8%2C461%2C276%3Bw%3D638/sign=d29242c8b8096b63955604103103ab7c/77c6a7efce1b9d16252e1f86f5deb48f8d546468.jpg&fm=36', '自通州行政副中心确立和通州8月限购以来，部分环北京楼市普遍升温，个别项目与年初相比甚至已上涨近一倍。', '2015-11-04', '王柏'),
(4, '北京保障扫雪铲冰：遇暴雪预警6小时内保障通行', 'http://t11.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C1%2C601%2C360%3Bw%3D638/sign=817535e35f82b2b7b3d063840c9de7de/c8177f3e6709c93d50fea310993df8dcd00054cc.jpg&fm=36', '以步道和背街小巷为主；将推进非氯化物融雪剂使用。', '2014-11-12', '张三'),
(5, '北京今年确保高速公路下雪不封路', 'http://t11.baidu.com/it/u=http://b.hiphotos.baidu.com/news/w%3D638/sign=e9c0a2fe2bf5e0feee188a02646234e5/4034970a304e251f8c15491fa186c9177e3e5372.jpg&fm=36', '扫雪铲冰预警由低到高划分为蓝色、黄色、橙色、红色4个级别，分别对应小雪、中雪、大雪和暴雪。', '0000-00-00', '李四'),
(6, '北京移动原副总受贿150万元被诉', 'http://t12.baidu.com/it/u=http://g.hiphotos.baidu.com/news/w%3D638/sign=417646b58335e5dd902ca6dc4ec7a7f5/9358d109b3de9c82dfec5f686a81800a18d8434f.jpg&fm=36', '朝阳法院昨日通报，此案已移送至该法院。', '0000-00-00', '王五'),
(7, '北京13日空气污染水平有所回落 15日将明显改善', 'http://t11.baidu.com/it/u=http://f.hiphotos.baidu.com/news/w%3D638/sign=e1cbf456860a19d8cb0387060bfb82c9/b812c8fcc3cec3fdd1770a92d088d43f8694278f.jpg&fm=36', '本市以冷空气控制为主，污染扩散条件较为有利，预计空气质量可维持在较好水平。', '0000-00-00', ''),
(8, '北京市委八次全会23日开 将审议通过十三五规划', 'http://t12.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C15%2C601%2C360%3Bw%3D638/sign=acd68fec5db5c9ea76bc59a3e8099a31/562c11dfa9ec8a13fb6aee07f103918fa1ecc0e1.jpg&fm=36', '全会将审议通过“北京市国民经济和社会发展十三五规划建议”。', '2015-11-16', ''),
(9, '京城“地王潮”是怎么炼成的', 'http://t12.baidu.com/it/u=http://e.hiphotos.baidu.com/news/crop%3D0%2C2%2C774%2C464%3Bw%3D638/sign=b41f10f2ba315c6057da31afb081e721/962bd40735fae6cd2f68178609b30f2443a70f7c.jpg&fm=36', '300个城市前9个月土地成交面积同比下降30.4%，这与北京土地市场形成了鲜明的对比。', '0000-00-00', ''),
(10, '北京解除霾黄色预警信号 大部分地区以雾为主', 'http://t12.baidu.com/it/u=http://e.hiphotos.baidu.com/news/crop%3D0%2C2%2C774%2C464%3Bw%3D638/sign=b41f10f2ba315c6057da31afb081e721/962bd40735fae6cd2f68178609b30f2443a70f7c.jpg&fm=36', '北京市气象台12日12时35分解除霾黄色预警信号。', '0000-00-00', ''),
(11, '北京教委回应民办高校上千学生突然停课', 'http://t11.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C2%2C799%2C479%3Bw%3D638/sign=59685e2ed12a6059465fbb5a150418a9/b58f8c5494eef01f324eaa22e6fe9925bd317dfa.jpg&fm=36', '13年、14年、15年，每年拖欠半年工资，14年、15年两个春节都不给发钱。\r\n', '0000-00-00', ''),
(12, '国家网信办约谈凤凰网负责人 北京网信办将依法予以处罚 ', 'http://t12.baidu.com/it/u=http://e.hiphotos.baidu.com/news/crop%3D0%2C2%2C774%2C464%3Bw%3D638/sign=b41f10f2ba315c6057da31afb081e721/962bd40735fae6cd2f68178609b30f2443a70f7c.jpg&fm=36', '切实履行主体责任，进行责任倒查，严肃处理相关部门及责任人，确保整改取得实效。', '0000-00-00', ''),
(13, '11月13日“糖尿病日” 北京市患病率高达9%', 'http://t12.baidu.com/it/u=http://e.hiphotos.baidu.com/news/crop%3D0%2C2%2C774%2C464%3Bw%3D638/sign=b41f10f2ba315c6057da31afb081e721/962bd40735fae6cd2f68178609b30f2443a70f7c.jpg&fm=36', '最新监测结果显示，北京市糖尿病患病率高达9.0%。', '0000-00-00', ''),
(14, '北京部分地区近期计划停电 含南河沿路和橡胶路等', 'http://t12.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C15%2C601%2C360%3Bw%3D638/sign=acd68fec5db5c9ea76bc59a3e8099a31/562c11dfa9ec8a13fb6aee07f103918fa1ecc0e1.jpg&fm=36', '5:00—19:00南河沿路、东城区东华门街道，韶九社区，锡拉胡同部分停电，东黄城根南街部分停...', '0000-00-00', ''),
(15, '北京铁路局开行海南汽车自驾游运输班列', 'http://t12.baidu.com/it/u=http://g.hiphotos.baidu.com/news/w%3D638/sign=417646b58335e5dd902ca6dc4ec7a7f5/9358d109b3de9c82dfec5f686a81800a18d8434f.jpg&fm=36', '办理好汽车托运手续后，市民可选择乘火车或其他交通工具到海南，于12月15日在海南海口南站取车。', '0000-00-00', ''),
(16, '立邦玩猫腻涉嫌价格欺诈 双11价格高于平时', 'http://t11.baidu.com/it/u=http://f.hiphotos.baidu.com/news/w%3D638/sign=e1cbf456860a19d8cb0387060bfb82c9/b812c8fcc3cec3fdd1770a92d088d43f8694278f.jpg&fm=36', '今后将在本市更多的公交专用车道上延伸至交叉路口和增设“借道区”交通标线，同时，还将视情况增设“...', '0000-00-00', ''),
(17, '北京食药监：羽利兴海米铝超标严重', 'http://t12.baidu.com/it/u=http://e.hiphotos.baidu.com/news/crop%3D0%2C2%2C774%2C464%3Bw%3D638/sign=b41f10f2ba315c6057da31afb081e721/962bd40735fae6cd2f68178609b30f2443a70f7c.jpg&fm=36', '这批标称福建省连江县闽海土特产加工厂生产的“羽利兴”精选海米，检测出不得检出的二氧化硫残留量和...', '0000-00-00', ''),
(18, '联发科为小米联想喊冤 有点倒霉被写成拒缴专利费', 'http://t11.baidu.com/it/u=http://h.hiphotos.baidu.com/news/w%3D638/sign=f82dbec0793e6709be0046fc03c69fb8/80cb39dbb6fd52668fbd7ef3ad18972bd5073646.jpg&fm=36', '搜狐科技从内部人士了解到，目前小米和高通的专利谈判，没有取得实质性进展，而即将发布的小米5可能...', '0000-00-00', ''),
(19, '双十一数据与中国经济之变', 'http://t12.baidu.com/it/u=http://a.hiphotos.baidu.com/news/w%3D638/sign=a56ac800972397ddd6799b076183b216/8435e5dde71190efb6946338c81b9d16fcfa60ee.jpg&fm=36', '2014年中国社会消费品单日零售额近719亿元人民币，而2015天猫双11全球狂欢节只用了17...', '0000-00-00', ''),
(20, '让“丑陋”的ERP变时尚', 'http://t12.baidu.com/it/u=http://g.hiphotos.baidu.com/news/w%3D638/sign=417646b58335e5dd902ca6dc4ec7a7f5/9358d109b3de9c82dfec5f686a81800a18d8434f.jpg&fm=36', '更关键的是，Infor移动配置器可与后台的ERP系统衔接，让供应链管理、库存管理也能可视化。', '0000-00-00', ''),
(21, '谷歌又造处理器又造手机，到底想干嘛？', 'http://t11.baidu.com/it/u=http://h.hiphotos.baidu.com/news/w%3D638/sign=f82dbec0793e6709be0046fc03c69fb8/80cb39dbb6fd52668fbd7ef3ad18972bd5073646.jpg&fm=36', '如果谷歌“亲儿子”真的要完全自主化，那么谷歌也是走上了自主控制硬件，实现软硬件深度整合的道路。', '0000-00-00', ''),
(22, '情报：观察链家的正确姿势（上）', 'http://t10.baidu.com/it/u=http://a.hiphotos.baidu.com/news/w%3D638/sign=ba0cebc4b67eca8012053ae4a9229712/b8389b504fc2d5628d289d0ae11190ef76c66c30.jpg&fm=36', '背后的逻辑就是这三个东西，由于链家同时具备了这三个逻辑效应，它的估值逻辑就完全不一样了。', '0000-00-00', ''),
(23, '相亲节目层出不穷，“剩女问题”能否得到解决？', 'http://t12.baidu.com/it/u=http://h.hiphotos.baidu.com/news/w%3D638/sign=ac27b42afa039245a1b5e20cbf96a4a8/d833c895d143ad4bbefa042784025aafa50f0604.jpg&fm=36', '背后的逻辑就是这三个东西，由于链家同时具备了这三个逻辑效应，它的估值逻辑就完全不一样了。', '0000-00-00', ''),
(24, '情报：观察链家的正确姿势（上）', 'http://t11.baidu.com/it/u=http://f.hiphotos.baidu.com/news/crop%3D0%2C1%2C266%2C160%3Bw%3D638/sign=7bbf3366cd1349546a51b2246b7ebe69/0eb30f2442a7d933edf56f94ab4bd11372f001f3.jpg&fm=36', '背后的逻辑就是这三个东西，由于链家同时具备了这三个逻辑效应，它的估值逻辑就完全不一样了。', '0000-00-00', ''),
(25, '双十一是个好“戏台”，但厂商莫成歪嘴和尚', 'http://t10.baidu.com/it/u=http://d.hiphotos.baidu.com/news/w%3D638/sign=bfb43593edf81a4c2632efcaef2b6029/64380cd7912397dd12c31fe35f82b2b7d1a2879b.jpg&fm=36', '无论是销量还是销售额，都排在前三甲。', '0000-00-00', ''),
(27, '北京市委副书记吕锡文接受调查 涉嫌严重违纪(图)', 'http://t10.baidu.com/it/u=http://e.hiphotos.baidu.com/news/w%3D638/sign=55cb1ec7b51bb0518f24b02b0e78da77/f3d3572c11dfa9ec76af44f264d0f703908fc156.jpg&fm=36', '搜狐科技从内部人士了解到，目前小米和高通的专利谈判，没有取得实质性进展，而即将发布的小米5可能...', '2015-11-12', ''),
(29, '北京市交通委:长安街公交专用道延伸至交叉路口', 'http://t12.baidu.com/it/u=http://d.hiphotos.baidu.com/news/crop%3D42%2C1%2C554%2C332%3Bw%3D638/sign=402e4a3aad64034f1b82984692f74b1d/71cf3bc79f3df8dcdad50b76cb11728b46102868.jpg&fm=36', '今后将在本市更多的公交专用车道上延伸至交叉路口和增设“借道区”交通标线，同时，还将视情况增设“...', '2015-11-04', ''),
(30, '通州8月限购以来部分环北京地区房价飙升', 'http://t11.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C8%2C461%2C276%3Bw%3D638/sign=d29242c8b8096b63955604103103ab7c/77c6a7efce1b9d16252e1f86f5deb48f8d546468.jpg&fm=36', '自通州行政副中心确立和通州8月限购以来，部分环北京楼市普遍升温，个别项目与年初相比甚至已上涨近一倍。', '2015-11-04', ''),
(31, '北京保障扫雪铲冰：遇暴雪预警6小时内保障通行', 'http://t11.baidu.com/it/u=http://b.hiphotos.baidu.com/news/w%3D638/sign=e9c0a2fe2bf5e0feee188a02646234e5/4034970a304e251f8c15491fa186c9177e3e5372.jpg&fm=36', '以步道和背街小巷为主；将推进非氯化物融雪剂使用。', '2014-11-12', ''),
(32, '北京今年确保高速公路下雪不封路', 'http://t11.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C1%2C601%2C360%3Bw%3D638/sign=817535e35f82b2b7b3d063840c9de7de/c8177f3e6709c93d50fea310993df8dcd00054cc.jpg&fm=36', '扫雪铲冰预警由低到高划分为蓝色、黄色、橙色、红色4个级别，分别对应小雪、中雪、大雪和暴雪。', '0000-00-00', ''),
(33, '北京移动原副总受贿150万元被诉', 'http://t11.baidu.com/it/u=http://a.hiphotos.baidu.com/news/crop%3D0%2C8%2C461%2C276%3Bw%3D638/sign=d29242c8b8096b63955604103103ab7c/77c6a7efce1b9d16252e1f86f5deb48f8d546468.jpg&fm=36', '朝阳法院昨日通报，此案已移送至该法院。', '0000-00-00', ''),
(34, '北京移动原副总受贿150万元被诉', 'http://t10.baidu.com/it/u=http://c.hiphotos.baidu.com/news/crop%3D0%2C1%2C422%2C253%3Bw%3D638/sign=3af3d194fdf2b211f061df0ef7b04909/32fa828ba61ea8d3d7d4c3e3910a304e241f5866.jpg&fm=36', '朝阳法院昨日通报，此案已移送至该法院。', '0000-00-00', ''),
(35, '北京13日空气污染水平有所回落 15日将明显改善', 'http://t10.baidu.com/it/u=http://e.hiphotos.baidu.com/news/w%3D638/sign=dc49bffe2bf5e0feee188a02646134e5/4034970a304e251fb99c541fa186c9177e3e53e9.jpg&fm=36', '本市以冷空气控制为主，污染扩散条件较为有利，预计空气质量可维持在较好水平。', '0000-00-00', ''),
(36, '北京市委八次全会23日开 将审议通过十三五规划', 'http://t12.baidu.com/it/u=http://b.hiphotos.baidu.com/news/w%3D638/sign=1a4602d6a78b87d65042a81c3f092860/503d269759ee3d6dfca1372c45166d224e4adef6.jpg&fm=36', '全会将审议通过“北京市国民经济和社会发展十三五规划建议”。', '0000-00-00', ''),
(37, '京城“地王潮”是怎么炼成的', 'http://t12.baidu.com/it/u=http://g.hiphotos.baidu.com/news/crop%3D0%2C2%2C746%2C448%3Bw%3D638/sign=1af4fa93edf81a4c327db689ea1a4c6b/3b292df5e0fe9925aaf621b732a85edf8cb1715a.jpg&fm=36', '300个城市前9个月土地成交面积同比下降30.4%，这与北京土地市场形成了鲜明的对比。', '0000-00-00', ''),
(38, '北京解除霾黄色预警信号 大部分地区以雾为主', 'http://t11.baidu.com/it/u=http://f.hiphotos.baidu.com/news/crop%3D0%2C2%2C800%2C480%3Bw%3D638/sign=0dae4c4c053b5bb5aa987abe0be3f90b/48540923dd54564eb7c2a9deb5de9c82d0584fb5.jpg&fm=36', '北京市气象台12日12时35分解除霾黄色预警信号。', '0000-00-00', ''),
(39, '北京解除霾黄色预警信号 大部分地区以雾为主', 'http://t12.baidu.com/it/u=http://a.hiphotos.baidu.com/news/w%3D638/sign=6efa33e1aaaf2eddd4f14aeab5120102/8d5494eef01f3a29350698299f25bc315d607c0e.jpg&fm=36', '北京市气象台12日12时35分解除霾黄色预警信号。', '0000-00-00', ''),
(40, '北京教委回应民办高校上千学生突然停课', 'http://t12.baidu.com/it/u=http://a.hiphotos.baidu.com/news/w%3D638/sign=baeaebc4b67eca8012053ae4a9219712/b8389b504fc2d5628dce9d0ae11190ef77c66c16.jpg&fm=36', '13年、14年、15年，每年拖欠半年工资，14年、15年两个春节都不给发钱。\r\n', '0000-00-00', ''),
(41, '国家网信办约谈凤凰网负责人 北京网信办将依法予以处罚 ', 'http://t11.baidu.com/it/u=http://inews.gtimg.com/newsapp_bt/0/94818439/1000&fm=36', '切实履行主体责任，进行责任倒查，严肃处理相关部门及责任人，确保整改取得实效。', '0000-00-00', ''),
(42, '11月13日“糖尿病日” 北京市患病率高达9%', 'http://t11.baidu.com/it/u=http://inews.gtimg.com/newsapp_bt/0/94819701/1000&fm=36', '最新监测结果显示，北京市糖尿病患病率高达9.0%。', '0000-00-00', ''),
(43, '北京部分地区近期计划停电 含南河沿路和橡胶路等', 'http://t10.baidu.com/it/u=http://inews.gtimg.com/newsapp_bt/0/94820939/1000&fm=36', '5:00—19:00南河沿路、东城区东华门街道，韶九社区，锡拉胡同部分停电，东黄城根南街部分停...', '0000-00-00', ''),
(44, '北京铁路局开行海南汽车自驾游运输班列', 'http://t12.baidu.com/it/u=http://g.hiphotos.baidu.com/news/w%3D638/sign=417646b58335e5dd902ca6dc4ec7a7f5/9358d109b3de9c82dfec5f686a81800a18d8434f.jpg&fm=36', '办理好汽车托运手续后，市民可选择乘火车或其他交通工具到海南，于12月15日在海南海口南站取车。', '0000-00-00', ''),
(45, '立邦玩猫腻涉嫌价格欺诈 双11价格高于平时', 'http://t11.baidu.com/it/u=http://f.hiphotos.baidu.com/news/w%3D638/sign=e1cbf456860a19d8cb0387060bfb82c9/b812c8fcc3cec3fdd1770a92d088d43f8694278f.jpg&fm=36', '今后将在本市更多的公交专用车道上延伸至交叉路口和增设“借道区”交通标线，同时，还将视情况增设“...', '0000-00-00', '诸葛明'),
(46, '北京食药监：羽利兴海米铝超标严重', 'http://t12.baidu.com/it/u=http://e.hiphotos.baidu.com/news/crop%3D0%2C2%2C774%2C464%3Bw%3D638/sign=b41f10f2ba315c6057da31afb081e721/962bd40735fae6cd2f68178609b30f2443a70f7c.jpg&fm=36', '这批标称福建省连江县闽海土特产加工厂生产的“羽利兴”精选海米，检测出不得检出的二氧化硫残留量和...', '0000-00-00', '王五'),
(47, '联发科为小米联想喊冤 有点倒霉被写成拒缴专利费', 'http://t11.baidu.com/it/u=http://h.hiphotos.baidu.com/news/w%3D638/sign=f82dbec0793e6709be0046fc03c69fb8/80cb39dbb6fd52668fbd7ef3ad18972bd5073646.jpg&fm=36', '搜狐科技从内部人士了解到，目前小米和高通的专利谈判，没有取得实质性进展，而即将发布的小米5可能...', '0000-00-00', 'Jamaica'),
(94, 'express', '/', 'd', '2015-12-06', ''),
(95, 'express 添加', '', '', '2015-12-07', '');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'lsc', '111');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
