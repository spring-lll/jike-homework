var client=require("../database");
mysql=client.getDbCon();

function News(news){
    this.newsid=news.newsid;
    this.newstitle=news.newstitle;
    this.newsimg=news.newsimg;
    this.newscontent=news.newscontent;
    this.adddate=news.adddate;
}
module.exports=News;

News.getList=function(keyword,start,nums,callback){
    var sql="select * from news where newstitle like '%"+keyword+"%' order by newsid desc limit "+start+","+nums;
    mysql.query(sql,function(err,result,fields){
        if(err){
            throw err;
        } else{
            callback(err,result,fields);
        }
    });
}


