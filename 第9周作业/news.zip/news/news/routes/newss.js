var express=require('express');
var router=express.Router();
var news=require("../models/backnews");
var http=require("http");
var url=require("url");

router.get("/delete",function(req,res,next){
    var parameter=url.parse(req.url,true).query;
    var news_=new news({
        newsid:parameter.newsid
    });
    news_.delete(function(err){
       if(err){
           throw err;
       } else{
           res.send(true);
       }
    });
});

router.get("/toUpdate", function (req,res,next) {
    var parameter=url.parse(req.url,true).query;
    news.get(parameter.newsid,function(err,u,fields){
        if(!u){
            res.send({status:false});
        }else{
            res.send({status:true,news:u});
        }
    });
});

router.post("/update",function(req,res,next){
    var news_=new news({
        newsid:req.body.newsid,
        newstitle:req.body.newstitle,
        newsimg:req.body.newsimg,
        newscontent:req.body.newscontent,
        adddate:req.body.adddate
    });
    news_.update(function (err) {
        if(err){
            throw err;
        }else{
            res.send(true);
        }
    });
});

router.get('/getList', function(req, res, next){
    var parameter = url.parse(req.url, true).query;
    news.getList(parameter.keyword, function(err, result, fields){
        if (err) {
            result = [];
        }
        res.send({result:result});
    });
});

router.get('/getDetail', function(req, res, next){
    var parameter = url.parse(req.url, true).query;
    news.getList(parameter.newsid, function(err, result, fields){
        if (err) {
            result = [];
        }
        res.send({result:result});
    });
});

router.post('/add',function(req,res,next){
    var news_=new  news({
        newstitle:req.body.newstitle,
        newsimg:req.body.newsimg,
        newscontent:req.body.newscontent,
        //adddate:req.body.adddate
    });
    news_.add(function(err,rs,fields){
        if(err){
            console.log("err=="+err);
            res.send({status:false,msg:"哎呀出错了"});
        } else{
            //console.log(res);
            res.send({status:true,msg:"添加成功"});
        }
    });
});

module.exports=router;