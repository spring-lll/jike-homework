var express=require('express');
var router=express.Router();
var news=require("../models/frontnews");
var http=require("http");
var url=require("url");

router.get('/front',function(req,res){
    res.render('front',{title:'百度新闻前台页面'});
});

router.get('/getList', function(req, res, next){
    var parameter = url.parse(req.url, true).query;
    news.getList(parameter.keyword,parameter.start,parameter.nums, function(err, result, fields){
        if (err) {
            result = [];
        }
        res.send({result:result});
    });
});

module.exports=router;
