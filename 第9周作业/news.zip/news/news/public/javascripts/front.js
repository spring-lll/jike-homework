$(function() {
    $('.content .news-type-item').click(function(){
        $('.content  .news-type-item').removeClass('cur');
        $(this).addClass('cur');
    });
    $(' .content .baijia').click(function() {
        $('.index-view-subpage').css('display', 'none');
        $('#index_view_baijia').css('display', 'block');
        getNewsList();
    });
    $(' .content .local').click(function() {
        $('.index-view-subpage').css('display', 'none');
        $('#index_view_local').css('display', 'block');
        localList();
    });
    localList();
});

//****************百家**************
function getNewsList(keyword,start,nums){
    $.get("/front/getList", {keyword: '',start:'17',nums:'5'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_baijia'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item'><div class='index-list-main showleft'>";
            html+="<div class='index-list-image'><i class='ivideoplay'></i><img src='"+value.newsimg+"'/></div>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>10分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="<div class='index-list-item'><div class='index-list-main'>";
        html+="<div class='index-list-main-text'><div class='index-list-main-title'>相亲节目层出不穷，“剩女问题”能否得到解决？</div></div>";
        html+="<div class='index-list-album-container'>";
        html+="<div class='index-list-album'><div class='index-list-album-wrapper one'><img src='/images/3812b31bb051f819593b10aedcb44aed2e73e73c.jpg' /></div></div>";
        html+="<div class='index-list-album'><div class='index-list-album-wrapper two'><img src='/images/f7246b600c338744f5933c98570fd9f9d62aa0fb.jpg' /></div></div>";
        html+="<div class='index-list-album appends'><div class='index-list-album-wrapper three'><img src='/images/f11f3a292df5e0fef5119ae55a6034a85fdf72cc.jpg' /></div></div>";
        html+="</div>";
        html+="</div></div><div id='contentss'></div>";
        html+="</div></div>";
        $("#index_view_sections").html(html);
    });
    $.get("/front/getList", {keyword: '',start:'1',nums:'2'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_baijia'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item'><div class='index-list-main showleft'>";
            html+="<div class='index-list-image'><i class='ivideoplay'></i><img src='"+value.newsimg+"'/></div>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.adddate+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="<div id='nw_contentsas'></div>";
        html+="</div></div>";
        $("#contentss").html(html);
    });
    $.get("/front/getList", {keyword: '',start:'11',nums:'1'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_baijia'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item no-image'><div class='index-list-main moretext'>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="<div id='nw_contentsbs'></div>";
        html+="</div></div>";
        $("#nw_contentsas").html(html);
    });
    $.get("/front/getList", {keyword: '',start:'1',nums:'1'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_baijia'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item'><div class='index-list-main showleft'>";
            html+="<div class='index-list-image'><i class='ivideoplay'></i><img src='"+value.newsimg+"'/></div>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="<div id='nw_contentsacs'></div>";
        html+="</div></div>";
        $("#nw_contentsbs").html(html);
    });
    $.get("/front/getList", {keyword: '',start:'12',nums:'1'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_baijia'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item no-image'><div class='index-list-main moretext'>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="<div id='nw_contentsds'></div>";
        html+="</div></div>";
        $("#nw_contentsacs").html(html);
    });
    $.get("/front/getList", {keyword: '',start:'13',nums:'8'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_baijia'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item'><div class='index-list-main showleft'>";
            html+="<div class='index-list-image'><i class='ivideoplay'></i><img src='"+value.newsimg+"'/></div>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="</div><div class='ui-refresh-wrapper'><div class='ui-refresh'>点击加载更多</div></div>";
        html+="</div>";
        $("#nw_contentsds").html(html);
    });
}


//****************本地**************
function localList(keyword,start,nums){
    $.get("/front/getList", {keyword: '',start:'10',nums:'1'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_local'>";
        html+="<div class='index-weather'>";
        html+="<div class='city-container'><div class='city'><span class='switch'>切换城市</span></div></div>";
        html+="<div class='topic-gallery-container' style='margin: 0px'><div class='topic-gallery ui-line-icons'><div class='g-list' style='height: 221px;transform: translateX(-730px);transition: none;'>";
        html+="<div class='g-item' style='width: 100%;'><div class='g-item-innerbox'><div class='g-imagebox' style='height: 221px;'><img src='images/timg.jpg' /></div><div class='g-title'><span>马布里25+8 北京爆冷负浙江</span></div></div></div>";
        html+="<div class='g-item' style='width: 100%;'><div class='g-item-innerbox'><div class='g-imagebox' style='height: 221px;'><img src='images/timg (1).jpg' /></div><div class='g-title'><span>马布里25+8 北京爆冷负浙江</span></div></div></div>";
        html+="<div class='g-item' style='width: 100%;'><div class='g-item-innerbox'><div class='g-imagebox' style='height: 221px;'><img src='images/timg (2).jpg' /></div><div class='g-title'><span>马布里25+8 北京爆冷负浙江</span></div></div></div>";
        html+="</div>";  //对应topic-gallery-container 里的g-list
        html+="<div class='g-icons'><i class='cur'></i></div>";
        html+="</div></div>"; //对应topic-gallery-container
        html+="</div>"; //index-weather
        html+="<div class='index-view-subpage-feed'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item'><div class='index-list-main showleft'>";
            html+="<div class='index-list-image'><i class='ivideoplay'></i><img src='"+value.newsimg+"'/></div>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="<div id='localcontentss'></div>";
        html+="</div></div>";
        html+="</div>";
        $("#index_view_sections").html(html);
    });
    $.get("/front/getList", {keyword: '',start:'2',nums:'16'}, function(result){
        var  html="<div class='index-view-subpage' style='' id='index_view_local'>";
        html+="<div class='index-view-subpage-feed'><div class='index-list'>";
        var data = eval(result);
        $.each(data.result, function(key, value){
            html+="<div class='index-list-item no-image'><div class='index-list-main moretext'>";
            html+="<div class='index-list-main-text'><div class='index-list-main-title'>"+value.newstitle+"</div><div class='index-list-main-abs'>"+value.newscontent+"</div></div>";
            html+="<div class='index-list-bottom'><div class='index-list-main-time'><b class='index-list-main-site'>+value.source+</b><b class='tip-time'>11分钟前</b></div></div>";
            html+="</div></div>";
        });
        html+="</div><div class='ui-refresh-wrapper'><div class='ui-refresh'>点击加载更多</div></div>";
        html+="</div></div>";
        html+="</div>";
        $("#localcontentss").html(html);
    });
}