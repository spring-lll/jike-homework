/**
 * Created by Administrator on 2015/12/3.
 */
var username,password;

//验证
function check() {
    var username_ = $("#username").val();
    var password_ = $("#password").val();
    if (username == ""||password == "") {
        alert("用户名或密码为空！");
        pwd.focus();
        return false;
    }else{
        username=username_;
        password=password_;
        return true;
    }
}

//登录
function login(){
    if(check()){
        $.post("/login",{
            username:username,
            password:password
        },function(res){
            if(res){
                location.href="/home";
            }else{
                $("#username").val("");
                $("#password").val("");
                alert("没有此用户记录");
            }
        });
    }else{
        return false;
    }
}

//加载
$(function(){

//    登录按钮事件
    $("#loginBtn").unbind("click");
    $("#loginBtn").bind("click",function(){
        login();
    });

//    键盘绑定事件
    document.onkeydown = function(e){
        var ev = document.all ? window.event : e;
        //Enter
        if(ev.keyCode==13) {
            login();
        }
    }
});