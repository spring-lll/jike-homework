<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<link rel="stylesheet" href="css/style.css" />
		<script type="text/javascript" src="js/jquery-2.1.0.js" ></script>
		<script type="text/javascript" src="js/app.js" ></script>
		<title>百度新闻</title>
	</head>

	<body>
		<div id="wrapper" class="news">
			<!--返回顶部-->
			<div class="gotop-globalview ui-gotop" style="position: fixed; z-index: 999;bottom: 200px;right: 10px; visibility: visible;display: none;">
				<span>&nbsp;</span>
			</div>
			<!--正文部分-->
			<div id="index_view" style="display: block;">
				<!--头部-->
				<header>
					<div class="ui-new-toolbar">
						<!--左上-->
						<div class="ui-new-toolbar-l">
							<div class="ui-new-toolbar-btn btn-baidu"></div>
							<div class="ui-new-toolbar-btn btn-userhome"></div>
						</div>
						<div class="ui-new-toolbar-r">
							<div class="ui-new-toolbar-btn btn-search"></div>
							<div class="ui-new-toolbar-btn btn-subscribe"></div>
						</div>
					</div>
				</header>
				<!--中间-->
				<div id="index_view_content">
					<!--导航-->
					<div id="index_view_navigator">
						<!--分割线-->
						<div class="divider"></div>
						<div class="content">
							<div class="content-type">
								<b></b>
								<span  style="cursor: pointer;" class="news-type-item baijia">百家</span>
							</div>
							<div>
								<b></b>
								<span class="news-type-item local cur" style="cursor: pointer;">本地</span>
							</div>
						</div>
					</div>
					<!--内容-->
					<div id="index_view_sections">
						<!--百家内容-->
						
						<div class="index-view-subpage" style="display: none;" id="index_view_baijia">
							<div class="index-list">
							<?php
								include("conn.php");
								$db=new mysql("localhost", "root", "","phplesson");
								$select=$db->select("news", "limit 17,5");
								while($row=$db->myArray($select)){
							?>
								<div class="index-list-item">
									<div class="index-list-main showleft">
										<div class="index-list-image">
											<i class="ivideoplay"></i>
											<img src="<?php echo $row['newsimg']?>" />
										</div>
										<div class="index-list-main-text">
											<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
											<div class="index-list-main-abs"><?php echo $row['newscontent']?></div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php } 	?>
								<div class="index-list-item">
									<div class="index-list-main">
										<div class="index-list-main-text">
											<div class="index-list-main-title">
												相亲节目层出不穷，“剩女问题”能否得到解决？
											</div>
										</div>
										<div class="index-list-album-container">
											<div class="index-list-album">
												<div class="index-list-album-wrapper one">
													<img src="img/3812b31bb051f819593b10aedcb44aed2e73e73c.jpg" />
												</div>
											</div>
											<div class="index-list-album">
												<div class="index-list-album-wrapper two">
													<img src="img/f7246b600c338744f5933c98570fd9f9d62aa0fb.jpg" />
												</div>
											</div>
											<div class="index-list-album">
												<div class="index-list-album-wrapper three">
													<img src="img/f11f3a292df5e0fef5119ae55a6034a85fdf72cc.jpg" />
												</div>
											</div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php
										$select=$db->select("news", "limit 1,2");
										while($row=$db->myArray($select))
									{
									?>
								<div class="index-list-item">
									<div class="index-list-main showleft">
										<div class="index-list-image">
											<i class="ivideoplay"></i>
											<img src="<?php echo $row['newsimg']?>" />
										</div>
										<div class="index-list-main-text">
											<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
											<div class="index-list-main-abs"><?php echo $row['newscontent']?></div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php } ?>
								<?php 
								$select=$db->select("news", "limit 24,1");
								$row=$db->myArray($select);
								?>
								<div class="index-list-item no-image">
									<div class="index-list-main moretext">
										<div class="index-list-main-text">
											<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
											<div class="index-list-main-abs"><?php echo $row['newscontent']?></div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php 
								$select=$db->select("news", "limit 0,1");
								$row=$db->myArray($select);
								?>
								<div class="index-list-item">
									<div class="index-list-main showleft">
										<div class="index-list-image">
											<i class="ivideoplay"></i>
											<img src="<?php echo $row['newsimg']?>" />
										</div>
										<div class="index-list-main-text">
											<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
											<div class="index-list-main-abs"><?php echo $row['newscontent']?></div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php 
								$select=$db->select("news", "limit 24,1");
								$row=$db->myArray($select);
								?>
								<div class="index-list-item no-image">
									<div class="index-list-main moretext">
										<div class="index-list-main-text">
											<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
											<div class="index-list-main-abs"><?php echo $row['newscontent']?></div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php
										$select=$db->select("news", "limit 17,8");
										while($row=$db->myArray($select))
									{
									?>
								<div class="index-list-item">
									<div class="index-list-main showleft">
										<div class="index-list-image">
											<i class="ivideoplay"></i>
											<img src="<?php echo $row['newsimg']?>" />
										</div>
										<div class="index-list-main-text">
											<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
											<div class="index-list-main-abs"><?php echo $row['newscontent']?></div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
								<?php } ?>
								<div class="index-list-item">
									<div class="index-list-main">
										<div class="index-list-main-text">
											<div class="index-list-main-title">
												开放二胎还不够
											</div>
										</div>
										<div class="index-list-album-container">
											<div class="index-list-album">
												<div class="index-list-album-wrapper one">
													<img src="img/a08b87d6277f9e2ff31835ec1930e924b899f321.jpg" />
												</div>
											</div>
											<div class="index-list-album">
												<div class="index-list-album-wrapper two">
													<img src="img/a044ad345982b2b79d43102037adcbef77099b71.jpg" />
												</div>
											</div>
											<div class="index-list-album">
												<div class="index-list-album-wrapper three">
													<img src="img/77094b36acaf2eddf62d600d8b1001e938019371.jpg" />
												</div>
											</div>
										</div>
										<div class="index-list-bottom">
											<div class="index-list-main-time">
												<b class="index-list-main-site">毛启盈</b>
												<b class="tip-time">11分钟前</b>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="ui-refresh-wrapper">
								<div class="ui-refresh">点击加载更多</div>
							</div>
						</div>
						<!--本地内容-->
						<div class="index-view-subpage" style="display: block;" id="index_view_local">
							<div class="index-weather">
								<div class="city-container">
									<div class="city">
										<span class="switch">切换城市</span>
									</div>
								</div>
								<div class="topic-gallery-container" style="margin: 0px">
									<div class="topic-gallery ui-line-icons">
										<div class="g-list" style="height: 221px;transform: translateX(-730px);transition: none;">
											<div class="g-item" style="width: 100%;">
												<div class="g-item-innerbox">
													<div class="g-imagebox" style="height: 221px;">
														<img src="img/timg.jpg" />
													</div>
													<div class="g-title">
														<span>马布里25+8 北京爆冷负浙江</span>
													</div>
												</div>
											</div>
											<div class="g-item" style="width: 100%;">
												<div class="g-item-innerbox">
													<div class="g-imagebox" style="height: 221px;">
														<img src="img/timg (1).jpg" />
													</div>
													<div class="g-title">
														<span>北京市就吕锡文被查表态：像珍惜生命一样珍惜名节和操守</span>
													</div>
												</div>
											</div>
											<div class="g-item" style="width: 100%;">
												<div class="g-item-innerbox">
													<div class="g-imagebox" style="height: 221px;">
														<img src="img/timg (2).jpg" />
													</div>
													<div class="g-title">
														<span>北京首虎吕锡文落马 全国31个省区市均有“虎”(名单)</span>
													</div>
												</div>
											</div>
										</div>
										<div class="g-icons">
											<i class="cur"></i>
										</div>
									</div>
								</div>
							</div>
							<?php
								$select=$db->select("news", "limit 0,1");
								$row=$db->myArray($select);
							?>
							<div class="index-view-subpage-feed">
								<div class="index-list">
									<div class="index-list-item">
										<div class="index-list-main showleft">
											<div class="index-list-image">
												<i class="ivideoplay"></i>
												<img src="img/Img426212572.jpg" />
											</div>
											<div class="index-list-main-text">
												<div class="index-list-main-title"><?php echo $row['newstitle'] ?></div>
												<div class="index-list-main-abs"><?php echo $row['newscontent'] ?></div>
											</div>
											<div class="index-list-bottom">
												<div class="index-list-main-time">
													<b class="index-list-main-site">毛启盈</b>
													<b class="tip-time">11分钟前</b>
												</div>
											</div>
										</div>
									</div>
									<?php
										$select=$db->select("news", "limit 1,16");
										while($row=$db->myArray($select))
									{
									?>
									<div class="index-list-item no-image">
										<div class="index-list-main moretext">
											<div class="index-list-main-text">
												<div class="index-list-main-title"><?php echo $row['newstitle']?></div>
												<div class="index-list-main-abs"><?php echo $row['newscontent'] ?></div>
											</div>
											<div class="index-list-bottom">
												<div class="index-list-main-time">
													<b class="index-list-main-site">毛启盈</b>
													<b class="tip-time">4分钟前</b>
												</div>
											</div>
										</div>
									</div>
									<?php
									}
									?>
								</div>
								<div class="ui-refresh-wrapper">
									<div class="ui-refresh">点击加载更多</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="index_view_lottery"></div>
				<!--脚部-->
				<div id="index_view_footer">
					<div class="ui-footer">
						<div class="item-wrapper">
							<div class="item feedback">意见反馈</div>
						</div>
						<div class="item-wrapper">
							<div class="item app-recommand">应用推荐</div>
						</div>
						<div class="item-wrapper">
							<div class="item app-download">客户端</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>

</html>