//$(".content .content-type .news-type-item").each(function(index) {
//	$('.content .content-type .news-type-item').live("click", function() {
//		$('.content .content-type .news-type-item').removeClass('cur');
//		$(this).eq(index).addClass('cur');
//		return false;
//	});
//});

$(function() {
	$('.content .news-type-item').click(function(){
		$('.content  .news-type-item').removeClass('cur');
		$(this).addClass('cur');
	});
	$(' .content .baijia').click(function() {
		$('.index-view-subpage').css('display', 'none');
		$('#index_view_baijia').css('display', 'block');
	});
	$(' .content .local').click(function() {
		$('.index-view-subpage').css('display', 'none');
		$('#index_view_local').css('display', 'block');
	});
});