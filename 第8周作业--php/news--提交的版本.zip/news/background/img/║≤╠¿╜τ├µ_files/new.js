$(".navbar-nav a").click(function(e) {
		$(this).tab("show");
	})
	//登录验证

function func() {
	var username = document.getElementById("username");
	if (username.value.length == 0||username.value=='') {
		alert("用户名不能为空！");
		username.focus();
		return false;
	}
	
	var pwd = document.getElementById("password");
	if(pwd.value.length == 0||pwd.value==''){
		alert("密码不能为空！");
		pwd.focus();
		return false;
	}
//	if()
}
