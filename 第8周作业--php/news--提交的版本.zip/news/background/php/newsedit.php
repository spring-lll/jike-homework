<?php
	include("conn.php");
	$db=new mysql("localhost", "root", "","phplesson");
	
	$id=$_GET["id"];
	$newstitle = $_REQUEST['newstitle'];
	$newsimg = $_REQUEST['newsimg'];
	$newscontent = $_REQUEST['newscontent'];
	$adddate = $_REQUEST['adddate'];
	
	$update=$db->update("news", "newstitle='$newstitle',newsimg='$newsimg',newscontent='$newscontent',adddate='$adddate'", "where newsid = '$id'");
	if (!$update) {
		die('Error: ' . mysql_error());
	} else {
		echo "修改成功";
	}
	$db->dbClose();
?>
