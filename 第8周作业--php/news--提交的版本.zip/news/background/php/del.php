<?php
	include("conn.php");
	$db=new mysql("localhost", "root", "","phplesson");
	
	$id=$_GET["id"];
	$delete = $db->delete("news","where newsid = '$id'");
	if (!$delete) {
		die('Error: ' . mysql_error());
	} else {
		echo "delete success";
	}
	$db->dbClose();
?>