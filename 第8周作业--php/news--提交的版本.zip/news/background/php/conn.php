<?php
	//创建mysql类
	class  mysql{
		private $host;  //服务器地址
		private $root;  //用户名
		private $password;  //密码
		private $database;  //数据库名
		
		//通过构建函数初始化类
		function __construct($host,$root,$password,$database){
			$this->host=$host;
			$this->root=$root;
			$this->password=$password;
			$this->database=$database;
			$this->connect();
		}
		
		//创建数据库连接方法
		function connect(){
			$this->conn=mysql_connect($this->host,$this->root,$this->password) or die("数据库连接错误".mysql_error());
			mysql_select_db($this->database,$this->conn);
			mysql_query("set names utf8");
		}
		
		//创建关闭数据库方法
		function dbClose(){
			mysql_close($this->conn);
		}
		
		//创建执行sql语句方法
		function query($sql){
			return mysql_query($sql);
		}
		
		//创建数组化方法
		function myArray($result){
			return mysql_fetch_array($result);
		}
		
		//创建返回结果集行数方法
		function rows($result){
			return mysql_num_rows($result);
		}
		
		//自定义查询方法
		function select($tableName,$condition){
			return $this->query("SELECT * FROM $tableName $condition");
		}
		
		//自定义插入数据方法
		function insert($tableName,$fields,$value){
			return $this->query("INSERT INTO $tableName $fields VALUES $value");
		}
		
		//自定义删除数据方法
		function delete($tableName,$condition){
			return $this->query("DELETE FROM $tableName $condition");
		}
		
		//自定义修改数据方法
		function update($tableName,$change,$condition){
			return $this->query("UPDATE $tableName SET $change $condition");
		}
		
	}
?>