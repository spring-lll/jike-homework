<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width,initial-scale=1" />
		<title>后台首页</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="../css/style.css" />
		<script type="text/javascript" src="../js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/new.js"></script>
	</head>

	<body>
		<!--头部-->
		<div class="myheading">
			<!--导航-->
			<nav class="navbar navbar-inverse">
				<div class="container">
					<div class="navbar-header">
						<!--品牌图标-->
						<a class="navbar-brand" href="">
							<img src="../img/white_logo.png" />
							<span>新闻后台管理系统</span>
						</a>
					</div>
					<div class="collapse navbar-collapse">
						<button type="button" class="btn btn-success navbar-btn navbar-right">Sign in</button>
						<form action="" class="navbar-form navbar-right" role="search">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="此搜索框暂时无效" />
							</div>
							<button type="submit" class="btn btn-default">搜索</button>
						</form>
					</div>
				</div>
			</nav>
		</div>
		<!--主体部分-->
		<div class="mybody container">
			<div class="row">
				<div class="leftmenu col-md-3 col-sm-5">
					<!--左边列表项-->
					<div class="list-group">
						<a href="news_list.php" class="list-group-item active nowuse">首页</a>
						<a href="../newsAdd.html" class="list-group-item nowuse">添加新闻</a>
						<a href="" class="list-group-item gray">删除新闻</a>
						<a href="" class="list-group-item gray">修改新闻</a>
						<a href="" class="list-group-item gray">个人中心</a>
						<a href="" class="list-group-item gray">资料查询</a>
						<a href="" class="list-group-item gray">公司概况</a>
						<a href="" class="list-group-item gray">帮助日志</a>
						<a href="" class="list-group-item gray">信息反馈</a>
						<a href="" class="list-group-item gray">个人主页</a>
						<a href="" class="list-group-item gray">历史消息</a>
						<a href="" class="list-group-item gray">其他内容</a>
					</div>
				</div>
				<!--右边内容部分-->

				<div class="content col-md-9 col-sm-7">
					<ol class="breadcrumb">
						<li><a href="">新闻后台管理系统</a></li>
						<li><a href="">用户管理</a></li>
						<li class="active">首页</a></li>
					</ol>
					<form action="select.php" method="post">
					<div class="row head">
						<div class="col-lg-5 floatr">
							<div class="input-group">
								<input name="titleinfo" id="titleinfo" type="text" class="form-control" placeholder="输入你所关注的新闻标题">
									<span class="input-group-btn">
											<input class="btn btn-info" type="submit" value="搜索">
												<span class="glyphicon glyphicon-search">
												</span>
											</input>
									</span>
							</div>
						</div>
					</div>
					</form>

					<?php
					//设置每一页显示的记录数
						$pagesize =8;
						//连接数据库
						include("conn.php");
						$db=new mysql("localhost", "root", "","phplesson");
						$sql = "select * from news";   //取得记录总数
						$rs = mysql_query($sql);
						$recordcount = mysql_num_rows($rs);
						$pagecount = ($recordcount - 1) / $pagesize + 1;
						$pagecount = (int)$pagecount;
						$pageno = $_REQUEST['pageno'];
						if (!isset($pageno)){
							$pageno=1;
						}
						if ($pageno < 1) {
							$pageno = 1;
						}else if ($pageno > $pagecount) {
							$pageno = $pagecount;
						}
						$startno = ($pageno - 1) * $pagesize;   //开始条数
						$sql = "select * from news order by newsid desc limit $startno,$pagesize";  //查询出所需要的条数
						$rs = mysql_query($sql);
					?>
					<div class="table-responsive">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 10%;">新闻ID</th>
									<th style="width: 15%;">新闻标题</th>
									<th style="width: 10%;">新闻图片</th>
									<th style="width: 30%;">新闻内容</th>
									<th style="width: 15%;">添加时间</th>
									<th style="width: 20%;">操作</th>
								</tr>
							</thead>
							<tbody>
								<?php
									while($rows=mysql_fetch_assoc($rs))
									{
								?>
								<tr>
									<td class=""><?php echo $rows["newsid"]?></td>
									<td class=""><?php echo mb_substr($rows["newstitle"],0,7,'utf-8')?></td>
									<td class=""><?php echo mb_substr($rows["newsimg"],0,17,'utf-8')?></td>
									<td class=""><?php echo mb_substr($rows["newscontent"],0,15,'utf-8')?></td>
									<td class=""><?php echo $rows["adddate"]?></td>
									<td class="">
										<a href="del.php?id=<?php echo $rows["newsid"] ?> class="mar-5"">删除</a>
										<a href="edit.php?id=<?php echo $rows["newsid"] ?>" class="mar-5">修改</a>
										<a href="newsdetail.php?id=<?php echo $rows["newsid"] ?>" class="mar-5">查看详情</a>
									</td>
								</tr>
								<?php
									}
								?>
									<tr>
							      <th colspan="6" align="right" class="textr">
							    <?php
							    $id=1;
								if($pageno==1)
								{
								?>
								首页 | 上一页 | <a href="?pageno=<?php echo $pageno+1?>&id=<?php echo $id?>">下一页</a> | <a href="?pageno=<?php echo $pagecount?>&id=<?php echo $pageno?>">末页</a>
								<?php
								}
								else if($pageno==$pagecount)
								{
								?>
								<a href="?pageno=1&id=<?php echo $id?>">首页</a> | <a href="?pageno=<?php echo $pageno-1?>&id=<?php echo $id?>">上一页</a> | 下一页 | 末页
								<?php
								}
								else
								{
								?>
								<a href="?pageno=1&id=<?php echo $id?>">首页</a> | <a href="?pageno=<?php echo $pageno-1?>&id=<?php echo $id?>">上一页</a> | <a href="?pageno=<?php echo $pageno+1?>&id=<?php echo $id?>" class="forumRowHighlight">下一页</a> | <a href="?pageno=<?php echo $pagecount?>&id=<?php echo $id?>">末页</a>
								<?php
								}
							?>
								&nbsp;第<?php echo $pageno ?>/<?php echo $pagecount ?>页&nbsp;共<?php echo $recordcount?>条记录 </th>
								  </tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!--脚部-->
			<div class="myfooter">
				<p>@百度新闻：news.baidu.com</p>
			</div>
		</div>
	</body>

</html>