<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width,initial-scale=1" />
		<title>后台界面</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="../css/style.css" />
		<script type="text/javascript" src="../js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/new.js"></script>
	</head>

	<body>
		<!--头部-->
		<div class="myheading">
			<!--导航-->
			<nav class="navbar navbar-inverse">
				<div class="container">
					<div class="navbar-header">
						<!--品牌图标-->
						<a class="navbar-brand" href="">
							<img src="../img/white_logo.png" />
							<span>新闻后台管理系统</span>
						</a>
					</div>
					<div class="collapse navbar-collapse">
						<button type="button" class="btn btn-success navbar-btn navbar-right">Sign in</button>
						<form action="" class="navbar-form navbar-right" role="search">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="此搜索框暂时无效" />
							</div>
							<button type="submit" class="btn btn-default">搜索</button>
						</form>
					</div>
				</div>
			</nav>
		</div>
		<!--主体部分-->
		<div class="mybody container">
			<div class="row">
				<div class="leftmenu col-md-3 col-sm-5">
					<!--左边列表项-->
					<div class="list-group">
						<a href="news_list.php" class="list-group-item  nowuse">首页</a>
						<a href="../newsAdd.html" class="list-group-item nowuse">添加新闻</a>
						<a href="" class="list-group-item gray">删除新闻</a>
						<a href="" class="list-group-item gray">修改新闻</a>
						<a href="" class="list-group-item gray">个人中心</a>
						<a href="" class="list-group-item gray">资料查询</a>
						<a href="" class="list-group-item gray">公司概况</a>
						<a href="" class="list-group-item gray">帮助日志</a>
						<a href="" class="list-group-item gray">信息反馈</a>
						<a href="" class="list-group-item gray">个人主页</a>
						<a href="" class="list-group-item gray">历史消息</a>
						<a href="" class="list-group-item gray">其他内容</a>
					</div>
				</div>
				<!--右边内容部分-->

				<div class="content col-md-9 col-sm-7">
					<ol class="breadcrumb">
						<li><a href="">新闻后台管理系统</a></li>
						<li><a href="">用户管理</a></li>
						<li class="active">查看新闻</a></li>
					</ol>
						<?php
						$id=$_REQUEST["id"];
						//根据新闻标题查找
						include("conn.php");
						$db=new mysql("localhost", "root", "","phplesson");
						$select=$db->select("news", "where newsid = '$id'");
						$row=mysql_num_rows($select);
						if($row>=1){
					?>
					<div class="table-responsive">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th style="width: 10%;">新闻ID</th>
									<th style="width: 15%;">新闻标题</th>
									<th style="width: 10%;">新闻图片</th>
									<th style="width: 30%;">新闻内容</th>
									<th style="width: 15%;">添加时间</th>
									<th style="width: 20%;">操作</th>
								</tr>
							</thead>
							<tbody>
								<?php
									while($array=$db->myArray($select))
									{
								?>
								<tr>
									<td class=""><?php echo $array["newsid"]?></td>
									<td class=""><?php echo $array["newstitle"]?></td>
									<td class=""><?php echo mb_substr($array["newsimg"],0,17,'utf-8')?></td>
									<td class=""><?php echo $array["newscontent"]?></td>
									<td class=""><?php echo $array["adddate"]?></td>
									<td class="">
										<a href="del.php?id=<?php echo $array["newsid"] ?>">删除</a>
										<a href="edit.php?id=<?php echo $array["newsid"] ?>" class="floatr">修改</a>
									</td>
								</tr>
								<?php
									}
									}else{
										echo "查不到任何数据";
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!--脚部-->
			<div class="myfooter">
				<p>@百度新闻：news.baidu.com</p>
			</div>
		</div>
	</body>

</html>