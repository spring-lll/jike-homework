<?php
//对数据库进行实例化
	include("conn.php");
	$db=new mysql("localhost", "root", "","phplesson");
	
	$newstitle = $_REQUEST['newstitle'];
	$newsimg = $_REQUEST['newsimg'];
	$newscontent = $_REQUEST['newscontent'];
	$adddate = $_REQUEST['adddate'];
	
	$insert=$db->insert("news"," (newstitle,newsimg,newscontent,adddate)","('" . $newstitle . "',  '" . $newsimg . "',  '" . $newscontent . "', '" . $adddate . "')");
	if (!$insert) {
		die('Error: ' . mysql_error());
	} else {
		echo "insert success";
	}
	$db->dbClose();
?>