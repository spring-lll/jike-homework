<!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width,initial-scale=1" />
		<title>后台界面</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="../css/style.css" />
		<script type="text/javascript" src="../js/jquery-2.1.0.js"></script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="../js/new.js"></script>
	</head>

	<body>
		<!--头部-->
		<div class="myheading">
			<!--导航-->
			<nav class="navbar navbar-inverse">
				<div class="container">
					<div class="navbar-header">
						<!--品牌图标-->
						<a class="navbar-brand" href="">
							<img src="../img/white_logo.png" />
							<span>新闻后台管理系统</span>
						</a>
					</div>
					<div class="collapse navbar-collapse">
						<button type="button" class="btn btn-success navbar-btn navbar-right">Sign in</button>
						<form action="" class="navbar-form navbar-right" role="search">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="此搜索框暂时无效" />
							</div>
							<button type="submit" class="btn btn-default">搜索</button>
						</form>
					</div>
				</div>
			</nav>
		</div>
		<!--主体部分-->
		<div class="mybody container">
			<div class="row">
				<div class="leftmenu col-md-3 col-sm-5">
					<!--左边列表项-->
					<div class="list-group">
						<a href="news_list.php" class="list-group-item">首页</a>
						<a href="../newsAdd.html" class="list-group-item">添加新闻</a>
						<a href="" class="list-group-item gray">删除新闻</a>
						<a href="" class="list-group-item  active gray">修改新闻</a>
						<a href="" class="list-group-item gray">个人中心</a>
						<a href="" class="list-group-item gray">资料查询</a>
						<a href="" class="list-group-item gray">公司概况</a>
						<a href="" class="list-group-item gray">帮助日志</a>
						<a href="" class="list-group-item gray">信息反馈</a>
						<a href="" class="list-group-item gray">个人主页</a>
						<a href="" class="list-group-item gray">历史消息</a>
						<a href="" class="list-group-item gray">其他内容</a>
					</div>
				</div>
				<!--右边内容部分-->

				<div class="content col-md-9 col-sm-7">
					<ol class="breadcrumb">
						<li><a href="">新闻后台管理系统</a></li>
						<li><a href="">用户管理</a></li>
						<li class="active">修改新闻</a>
						</li>
					</ol>
					<?php
					$id=$_GET["id"];
					include("conn.php");
					$db=new mysql("localhost", "root", "","phplesson");
					$select=$db->select("news", "where newsid = '$id'");
					$row=$db->myArray($select);
					$db->dbClose();
					?>
					<div class="table-responsive">
						<form action="newsedit.php?id=<?php echo $row["newsid"] ?>" method="post">
							<p>
								<label for="newstitle">新闻&nbsp;&nbsp;&nbsp;ID</label>
								<input type="text" name="newstitle" id="newstitle" value="<?php echo $id?>" readonly/>
							</p>
							<p>
								<label for="newstitle">新闻标题  </label>
								<input type="text" name="newstitle" id="newstitle" value="<?php echo $row['newstitle']?>" />
							</p>
							<p>
								<label for="newsimg">图片地址</label>
								<input type="text" name="newsimg" id="newsimg" value="<?php echo $row['newsimg']?>" />
							</p>
							<p>
								<label for="newscontent">新闻内容</label>
								<textarea name="newscontent" rows="" cols="" id="newscontent"><?php echo $row['newscontent']?></textarea>
							</p>
							<p>
								<label for="adddate">添加时间</label>
								<input type="date" name="adddate" id="adddate" value="<?php echo $row['adddate']?>" />
							</p>
							<input type="submit" name="submitBtn" id="submitBtn" value="提交" />
							 <a href='javascript:history.go(-1);'><input type="button" value="返回" ></a>
						</form>
					</div>
				</div>
			</div>
			<!--脚部-->
			<div class="myfooter">
				<p>@百度新闻：news.baidu.com</p>
			</div>
		</div>
	</body>

</html>