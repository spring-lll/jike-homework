/**
 * Created by Administrator on 2015/12/14.
 */
module.exports = function(grunt) {

    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        //合并
        concat: {
            bar:{
                src:['js/*.js'],
                dest:'build/all.js'
            }
        },
        //编译sass
        sass: {
            dynamic_mappings: {
                files: [{
                    expand: true,
                    cwd: 'sass',
                    src: ['*.scss'],
                    dest: './public',
                    ext: '.css'
                }],
            }
        },
        //压缩js
        uglify: {
            options: {
                banner: '/*! create by <%= grunt.template.today("yyyy-mm-dd") %> */\n'
            },
            static_mappings: {
                //src: 'src/<%= pkg.name %>.js',
                //dest: 'build/<%= pkg.name %>.min.js'
                files: [{
                    src:['build/all.js'],
                    dest:'dest/all.min.js'
                }],
            }
        },
        //    压缩css
        cssmin: {
            bars:{
                src:['public/*.css'],
                dest:'dest/all.min.css'
            }
        },
        //压缩HTML
        htmlmin: {
            options:{
                removeComments: true,
                removeCommentsFromCDATA: true,
                collapseWhitespace: true,
                collapseBooleanAttributes: true,
                removeAttributeQuotes: true,
                removeRedundantAttributes: true,
                useShortDoctype: true,
                removeEmptyAttributes: true,
                removeOptionalTags: true
            },
            html:{
                files: [{
                    expand: true,
                    cwd: './',
                    src: ['*.html'],
                    dest: './dest',
                    ext: '.html'
                }]
            }
        },
    //    图片压缩
        imagemin: {
            /* 压缩图片大小 */
            dist: {
                files: [{
                    expand: true,
                    cwd: "./images/",
                    src: ["**/*.{jpg,png,gif}"],
                    dest: "./images/"
                }]
            }
        },
    //    js检查
        jshint: {
            files: ['Gruntfile.js', 'js/new.js','js/app.js'],
            options: {
                //这里是覆盖JSHint默认配置的选项
                globals: {
                    jQuery: true,
                    console: true,
                    module: true,
                    document: true
                }
            }
        },
    //    监听
        watch: {
            files: ['sass/*.scss'],
            tasks: ['sass']
        }
    });

    // 加载包含 "uglify" 任务的插件。
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-htmlmin');
    grunt.loadNpmTasks('grunt-contrib-imagemin');
    grunt.loadNpmTasks('grunt-contrib-jshint');
    grunt.loadNpmTasks('grunt-contrib-watch');

    // 默认被执行的任务列表。
    grunt.registerTask('default', ['concat','sass','uglify','cssmin','htmlmin','imagemin','jshint']);

};